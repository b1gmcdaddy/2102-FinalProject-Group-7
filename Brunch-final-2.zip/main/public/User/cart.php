<?php

include '../../Config/db_config.php';
session_start();

$conn = OpenCon();

		

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
     <link rel="stylesheet" href="../../src/css/stylesheet.css">
<link rel="stylesheet" href="../../src/css/order.css">
     <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">
</head>

<body>
   <body style="background-color: #EAEBE6;">

  <!-- HEADER -->
  <nav>
    <input type="checkbox" id="check">
    <label for="check" class="checkbtn">
      <i class="fas fa-bars"></i>
    </label>
    <div class="logo">
      <p>BRUNCH</p>
    </div>
    <ul>
      <li><p>Hi <?php echo $_SESSION['username']; ?>!</p></li>
       <li><a href="index.php">HOME</a></li>
      <li><a href="menu.php">MENU</a></li>
      <li><a href="contact.php">CONTACT</a></li>
      <li><a href="about.php">ABOUT</a></li>
      <li><a href="logout.php">LOGOUT</a></li>
	<li><a href="cart.php"><i class = "bi bi-cart2"></i></a>
	<?php
				
		$sql = "SELECT SUM(quantity) AS total FROM order_details WHERE orderID IN (SELECT orderID FROM customer_order WHERE customerID = " . $_SESSION["userid"] . ");";
		$result = $conn->query($sql);
		$temp = $result->fetch_assoc();
		if ($temp["total"] === NULL){
			echo 0;
		}else{
   			echo $temp['total'];
		}

			?>
	</li>
    </ul>
  </nav>

    <div id="label" class="text-center">
    <?php
        
        $total = 0;
 		$sql = "SELECT oi.foodID, oi.orderID, (SUM(oi.quantity) * p.food_price) AS ProductPayment
                FROM order_details oi, customer_order od, food_menu p
                WHERE oi.orderID = od.orderID
                    AND oi.foodID = p.foodID
                    AND oi.orderID IN (
                        SELECT orderID
                        FROM customer_order
                        WHERE customerID = ".$_SESSION['userid']."
                    )
                GROUP BY oi.foodID;";
		$result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $total += $row['ProductPayment'];  
    ?>
	<?php
            } 
            $_SESSION['totalPayment'] = $total;
           
    ?>

            <h2>Total Bill : ₱<?php echo $total?></h2>
    <?php
	
    } else {
        echo "<h2>Total Bill : ₱0	</h2>";
    }
    ?>

	<a href="payment.php">
    <button type="submit" name="submit" onClick="payment.php" class="checkout">Checkout</button>
    </a>
	

   </div>

<?php
		$sql = "SELECT * FROM food_menu p, order_details oi, customer_order od
			WHERE  p.foodID = oi.foodID 
                AND oi.orderID = od.orderID
                AND oi.orderID IN (
                    SELECT orderID
                    FROM customer_order
                    WHERE customerID = " . $_SESSION["userid"] . "
                )
			ORDER BY oi.foodID;";

		$result = mysqli_query($conn, $sql);
			if (mysqli_num_rows($result) > 0) {
			    while ($row = mysqli_fetch_assoc($result)) {
                    $sql = "SELECT quantity 
                            FROM order_details 
                            WHERE orderID IN (
                                SELECT orderID
                                FROM customer_order 
                                WHERE customerID = " . $_SESSION["userid"] . "
                            ) 
                            AND foodID = ". $row["foodID"];
                    $temp = $conn->query($sql);
                    $quantity = $temp->fetch_assoc();
    ?>

	   <div class="shopping-cart" id="shopping-cart">
                    <br>
                    <div class="cart-item">
                    <div class="details">
                        <h1><?php echo $row['food_name'] ?></h1>
                        <h4>Description: <?php echo $row['food_desc'] ?></h4>
                        
                        <hr>
                        <div class="price-quantity">
                            <h2> ₱ <?php echo ($row['food_price'] * $quantity["quantity"])?></h2>
                            <form action="update.php" method="post">
                                <div class="buttons">
                                    <button type="submit" name="subtract_from_cart" value="-" class="bi bi-dash-lg"></button>
                                    <div class="quantity">
                                        <h3><?php echo ($quantity["quantity"])?></h3>
                                    </div>
                                    <button type="submit" name="add_to_cart" value="+" class="bi bi-plus-lg"></button>
                                </div>
                                <input type="hidden" name="id" value="<?php echo $row['foodID']; ?>">
                                <input type="hidden" name="price" value="<?php echo $row['food_price']; ?>">
                            </form>
                        </div>
                    </div>
                    </div>
                    </div>
    <?php
                }
            } else {
                echo "        
                    
                </div>";
            }
                mysqli_close($conn);
    ?>



    <div id="label" class="text-center"></div>


 <!-- FOOTER -->
  <footer class="footer">
    <div class="footer__addr">
      <h1 class="footer__logo">Brunch</h1>
          
      <h2>Contact</h2>
      
      <address>
        09 422 6555 (ext. 1)<br>
            
        <a class="footer__btn" href="@brunch.co.ph">Email Us</a>
      </address>
    </div>
    
    <ul class="footer__nav">
      <li class="nav__item">
        <h2 class="nav__title">Brunch</h2>
  
        <ul class="nav__ul">
          <li>
            <a href="menu.php">Menu</a>
          </li>
  
          <li>
            <a href="contact.php">Contact</a>
          </li>
              
          <li>
            <a href="about.php">About</a>
          </li>
        </ul>
      </li>
      
      <li class="nav__item nav__item--extra">
        <h2 class="nav__title">Social Media</h2>
        
        <ul class="nav__ul nav__ul--extra">
          <li>
            <a href="#">Facebook</a>
          </li>
          
          <li>
            <a href="#">Instagram</a>
          </li>
          
          <li>
            <a href="#">Twitter</a>
          </li>
    
    <div class="legal">
      <p>&copy; 2022 Brunch. All rights reserved.</p>
      <p>Serving you magnificence.</p>
      
    </div>
  </footer>
<!-- END OF FOOTER -->

</body>

</html>