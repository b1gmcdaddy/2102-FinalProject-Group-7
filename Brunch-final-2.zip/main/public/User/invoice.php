<?php
session_start();
include "../../Config/db_config.php";

$conn = OpenCon();
$method = $_POST["payment-method"];

// select from customer_order if customerID is current sessions user
// BEFORE: customerID = 1
$get_order_id = "SELECT orderID FROM customer_order WHERE customerID = ".$_SESSION['userid'].";";
$temp = $conn->query($get_order_id);
$order_id = $temp->fetch_object();

if($temp->num_rows > 0){ 

   	$sql = mysqli_query($conn, "INSERT INTO `payment`(payment_date,payment_method,orderID) VALUES ('" . date("Y-m-d") . "','" . $method . "'," . $order_id->orderID . ");");

    $delete_cart = "DELETE FROM customer_order WHERE customerID=".$_SESSION['userid'].";";
    $conn->query($delete_cart);

    $delete_orderId = "DELETE FROM customerID WHERE orderID=".$order_id->orderID.";";
}
else{
    echo "<script> window.history.go(-1); </script>";
}

header("location:menu.php");
?>