<?php

include '../../Config/db_config.php';
session_start();

$conn = OpenCon();

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
     <link rel="stylesheet" href="../../src/css/stylesheet.css">
    <link rel="stylesheet" href="../../src/css/order.css">
     <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">

     <style>
form{
  margin: 2em auto;
}
span {
  font-size: 18px;
  color: #333;
  }
h1.yellow {
  font-size: 32px;
  font-weight: bold;
}

ul.list-group {
  list-style: none;
  padding: 0;
  margin: 0;
}

li.list-group-item {
  background-color: #F5F5F5;
  border: 1px solid #DDD;
  margin-bottom: 8px;
  padding: 15px;
}

li.list-group-item small.text-muted {
  color: #888;
  font-size: 14px;
}

li.list-group-item span.text-muted {
  float:right;
  font-size: 14px;

}

div.custom-control {
  font-size: 14px;
  position: relative;
  display: block;
  min-height: 1.5rem;
  padding-left: 1.5rem;
}

input.custom-control-input {
  position: absolute;
  z-index: -1;
  opacity: 0;
}

label.custom-control-label::before,
label.custom-control-label::after {
  position: absolute;
  top: 0;
  left: 0;
  display: block;
  width: 1rem;
  height: 1rem;
  content: "";
}

label.custom-control-label::before {
  background-color: #ddd;
  border-radius: 0.25rem;
  transition: background-color 0.15s ease-in-out;
}

input.custom-control-input:checked ~ label.custom-control-label::before {
  background-color: #333;
}

label.custom-control-label::after {
  background: no-repeat 50%/50% 50%;
}

input.custom-control-input:checked ~ label.custom-control-label::after {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3e%3cpath fill='%23fff' d='M6.564.75l-3.59 3.612-1.538-1.55L0 4.26 2.974 7.25 8 2.193z'/%3e%3c/svg%3e");
}
</style>
</head>

<body>
   <body style="background-color: #EAEBE6;">

  <!-- HEADER -->
  <nav>
    <input type="checkbox" id="check">
    <label for="check" class="checkbtn">
      <i class="fas fa-bars"></i>
    </label>
    <div class="logo">
      <p>BRUNCH</p>
    </div>
    <ul>
       <li><a href="index.php">HOME</a></li>
      <li><a href="menu.php">MENU</a></li>
      <li><a href="contact.php">CONTACT</a></li>
      <li><a href="about.php">ABOUT</a></li>
	<li><a href="cart.php"><i class = "bi bi-cart2"></i></a>
	<?php
				
		$sql = "SELECT SUM(quantity) AS total FROM order_details WHERE orderID IN (SELECT orderID FROM customer_order WHERE customerID = " . $_SESSION["userid"] . ");";
		$result = $conn->query($sql);
		$temp = $result->fetch_assoc();
		if ($temp["total"] === NULL){
			echo 0;
		}else{
   			echo $temp['total'];
		}

			?>
	</li>
    </ul>
  </nav>


 <form action="invoice.php" method="post">
	<!-- Cart Section -->
          <?php
            $total = $_SESSION["totalPayment"];

            $result = mysqli_query($conn, $sql);

          $sql = "SELECT * 
                FROM order_details oi, customer_order od, food_menu p
                WHERE oi.orderID = od.orderID
                    AND oi.foodID = p.foodID
                    AND oi.orderID IN (
                        SELECT orderID
                        FROM customer_order
                        WHERE customerID = ".$_SESSION['userid']."
                    )
                GROUP BY oi.foodID;";

            $result = mysqli_query($conn, $sql);
              if (mysqli_num_rows($result) > 0) {
                  while ($row = mysqli_fetch_assoc($result)) {
                    $name = $row['food_name'];
                    $quantity = $row['quantity'];
                    $sql = "SELECT SUM(quantity) AS value_sum 
                            FROM order_details 
                            WHERE orderID IN (
                              SELECT orderID
                              FROM customer_order
                              WHERE customerID = 1
                            )";
                    $result = mysqli_query($conn, $sql); 
                    $row = mysqli_fetch_assoc($result); 
                    $sum = $row['value_sum'];	
            ?>
          <div class="col-md-4">
            <div class="card card-blue p-3 text-white mb-3">
              <span>
                You have to pay
              </span>
              <div class="d-flex flex-row align-items-end mb-3">
                <h1 class="mb-0 yellow">
                  ₱<?php echo $total ?>
                </h1>
              </div>
              <span>
                No. of Items:
                <b style="color: #008000; font-size:20px;">
                  <?php echo $sum ?> pcs.
                </b>
              </span>
            
              <ul class="list-group mb-3">
              <?php
                $sql = "SELECT oi.quantity, p.food_name, p.food_price
                        FROM order_details oi 
                        INNER JOIN food_menu p 
                          ON oi.foodID = p.foodID
                        WHERE oi.orderID IN (
                          SELECT orderID 
                          FROM customer_order 
                          WHERE customerID = ".$_SESSION['userid']."
   
                        );";
                $result = mysqli_query($conn, $sql);
                  if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                      $name = $row['food_name'];
                      $quantity = $row['quantity'];
                      $product_price = $row['food_price'];
              ?>	
                      <li class="list-group-item d-flex justify-content-between lh-condensed">
                        <div>
                          <!-- <h6 class="my-0">Product name</h6> -->
                          <small class="text-muted">
                            <?php echo $quantity?>x <?php echo $name?><span class="text-muted">
                          ₱<?php echo $product_price*$quantity?>
                        </span>
                          </small>
                        </div>
                        
                      </li>
	
              <?php
                    }
                  }
              ?> 
              </ul>
		<div class="row mt-3">
                <div class="col-md-6">
                  <div class="mt-1 mr-2"><br>
                    Choose a payment method:
                    <div class="custom-control custom-radio">
                      <input id="credit" name="payment-method" type="radio" class="custom-control-input" value="credit"
                      checked required>
                      <label class="custom-control-label" for="credit">
                      Cash
                      </label>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="mt-1 mr-2">
                    <div class="custom-control custom-radio">
                      <input id="debit" name="payment-method" type="radio" class="custom-control-input" value="debit"
                      required>
                      <label class="custom-control-label" for="debit">
                        Credit
                      </label>
                    </div>
                  </div>
                </div>
              </div>
		<a href="invoice.php">
   	 <button type="submit" name="submit" onClick="invoice.php" class="checkout">Pay now</button>
   	 </a>
              <?php

      }
	
    } else {
      echo "        <div class='item'>
      <div class='details'>
          <h1>0 Products</h1>
      </div>
	
  </div>";
    }
    mysqli_close($conn);
    ?>
</form><br><br><br>
</div>


 <!-- FOOTER -->
 <footer class="footer">
    <div class="footer__addr">
      <h1 class="footer__logo">Brunch</h1>
          
      <h2>Contact</h2>
      
      <address>
        09 422 6555 (ext. 1)<br>
            
        <a class="footer__btn" href="@brunch.co.ph">Email Us</a>
      </address>
    </div>
    
    <ul class="footer__nav">
      <li class="nav__item">
        <h2 class="nav__title">Brunch</h2>
  
        <ul class="nav__ul">
          <li>
            <a href="menu.php">Menu</a>
          </li>
  
          <li>
            <a href="contact.php">Contact</a>
          </li>
              
          <li>
            <a href="about.php">About</a>
          </li>
        </ul>
      </li>
      
      <li class="nav__item nav__item--extra">
        <h2 class="nav__title">Social Media</h2>
        
        <ul class="nav__ul nav__ul--extra">
          <li>
            <a href="#">Facebook</a>
          </li>
          
          <li>
            <a href="#">Instagram</a>
          </li>
          
          <li>
            <a href="#">Twitter</a>
          </li>
    
    <div class="legal">
      <p>&copy; 2022 Brunch. All rights reserved.</p>
      <p>Serving you magnificence.</p>
      
    </div>
  </footer>
<!-- END OF FOOTER -->

  </body>
  </html>

