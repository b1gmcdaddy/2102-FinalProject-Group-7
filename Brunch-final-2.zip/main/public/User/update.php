<?php
include '../../Config/db_config.php';
$order_item_price = $_POST["price"];
$product_id = $_POST["id"];
$conn = OpenCon();

//Put SQL code here;
session_start();
$get_order_id = "SELECT orderID FROM customer_order WHERE customerID = " . $_SESSION["userid"] . ";";
$temp = $conn->query($get_order_id);
$order_id = $temp->fetch_object();
$checksum = $order_id;
$quantity = 1;

if(!empty($order_id)){
	$conn->query("INSERT INTO customer_order(customerID,order_date) VALUES(".$_SESSION['userid'].",'" . date("Y-m-d") . "');");
	$temp = $conn->query($get_order_id);
	$order_id = $temp->fetch_object();
}

$get_product_details = "SELECT food_desc FROM food_menu WHERE foodID = " . $product_id . ";";
$other_product_details = $conn->query($get_product_details);

$sql = "SELECT foodID FROM order_details WHERE orderID = ". $order_id->orderID." AND foodID = ".$product_id.";";
$result = $conn->query($sql);
if ($result->num_rows > 0){
	$sql = "UPDATE order_details SET quantity = (quantity + " . $quantity . ") WHERE foodID = " . $product_id . " AND orderID = " . $order_id->orderID;
}else if($result->num_rows == 0){
	$sql = "INSERT INTO order_details(foodID,orderID,quantity) VALUES (" . $product_id . "," . $order_id->orderID . ",1);";
}
$sql2 = "UPDATE order_details SET total_amount = (total_amount + (". $order_item_price . " * " . $quantity . ")) WHERE orderID = ". $order_id->orderID .";";
$conn->query($sql);
$conn->query($sql2);
$sql = "DELETE FROM order_details WHERE quantity = 0";
$conn->query($sql);
echo "<script>
             window.history.go(-1);
     </script>";
?>