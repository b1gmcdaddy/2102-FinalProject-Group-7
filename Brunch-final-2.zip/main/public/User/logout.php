<?php

    session_start();

    if(isset($_SESSION['username']) && isset($_SESSION['userid'])) {
        unset($_SESSION['username']);
        unset($_SESSION['userid']);
    }

    header('location:../login.php');

?>