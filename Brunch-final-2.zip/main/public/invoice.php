<?php
session_start();
include "../Config/db_config.php";

$conn = OpenCon();
    $method = $_POST["payment-method"];
    // select from customer_order if customerID is current sessions user
    // BEFORE: customerID = 1
    $get_order_id = "SELECT orderID FROM customer_order WHERE customerID = ".$_SESSION['userid'].";";
	$temp = $conn->query($get_order_id);
	if($temp->num_rows > 0){ 
	$order_id = $temp->fetch_assoc();

   	$sql = "INSERT INTO payment(payment_date,payment_method,orderID) VALUES (" . date("Y-m-d") . "," . $method . "," . $order_id["orderID"] . ")";

    $conn->query($sql);
}
else{
echo "<script>
                window.history.go(-1);
        </script>";
}



    ?>
