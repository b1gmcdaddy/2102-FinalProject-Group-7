<?php

session_start();


$username = $_POST['username'];
$password = $_POST['password'];

$db = mysqli_connect('localhost', 'root', '');
  mysqli_select_db($db, '2102');

$query = "SELECT * FROM customer WHERE Username='$username' AND Password='$password'";
$result = mysqli_query($db, $query);

if (mysqli_num_rows($result) == 1) {
  $sql_records = $result->fetch_object();
  
  $_SESSION['logged_in'] = true;
  $_SESSION['username'] = $username;
  // set session userid to current customer/user
  $_SESSION['userid'] = $sql_records->customerID;
  echo "<script>console.log(".$sql_records->customerID.")</script>";
  header('location: User/index.php');
} else {
  // Login is unsuccessful
  $_SESSION['message'] = 'Login failed. Invalid username or password';
  header('location: login.php');
}

?>
