<!DOCTYPE html>
<html>
    <head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
     <link rel="stylesheet" href="../src/css/stylesheet.css">
     <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">
     <title>Homepage</title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
<body style="background-color: #EAEBE6;">

  <!-- HEADER -->
  <nav>
    <input type="checkbox" id="check">
    <label for="check" class="checkbtn">
      <i class="fas fa-bars"></i>
    </label>
    <div class="logo">
      <p>BRUNCH</p>
    </div>
    <ul>
       <li><a href="../public/index.php">HOME</a></li>
    
      <li><a href="../public/contact.php">CONTACT</a></li>
      <li><a href="../public/login.php">ACCOUNT</a></li>
      <li><a href="../public/about.php">ABOUT</a></li>

    </ul>
  </nav>

  <!-- BANNER IMAGE -->
  <div class="bgimage">
    <img src= '../src/img/banner.jpg'> </div>


  <!-- ABOUT US SECTION -->
  <div class="about-container">
    <div class="about-title"><h1>OUR RESTAURANT</h1> <br> <hr> <br></div>
    <p class="about-text">
      Having moved from the original site in Leigh, Brunch has been turning out dishes from premises just out of Matakana since February 2016. The end of July 2016 we opened the doors to visitors and locals to experience the kind of hospitality Brunch is about - straight forward and generous.
     <br> <br> We have a talented team of chefs, managers and charismatic staff across our locations, and while each restaurant has its own charm, they all remain true to our central ethos which is to provide contemporary food made with the finest ingredients, served to the highest standards.</p>
  </div>

  <br> <br> <br>

  <!-- OPENING HOURS SECTION -->
  <div class="opening-hours-container">
    <img src="../src/img/opening-hours.jpg">
    <div class ="opening-hours-title"><h1>OPENING HOURS</h1></div>

    <div class="opening-hours-text">
      <h2 class="hours-title">DAYTIME</h2>
        <p class="hours-text">We are a walk-in only venue between 12pm - 5.30pm. <br> Just come on in at any time and we will accommodate you <br>on your arrival.
          If you're a group of 20 or more people, please see <br>info on group bookings below.</p> <br>
      <h2 class="hours-title">DINNER</h2>
        <p class="hours-text">Reservations indoors for the Smoko Room can be made <br>for dinner from 5.30pm  onwards for any number of guests. <br>To make a reservation email smokoroom@sawmillbrewery.co.nz or <br>call 09 422 6555 (ext. 1). 
          We don't take reservations for our outdoor area so <br> please come early to secure a table if you'd like to dine outside. </p>
    </div> 
  </div> <br> <br> <br>

   <!-- MENU SECTION -->
    <div class="menu-container">
      <div class="menu-title"><h1>MENU</h1> <hr> <br></div>
     
      <div class="menu-items-container">

        <div class="menu-column" >
          <h2>Appetizer</h2> <br>
          <div class="item-container">
            <div class="item-1">
              <h3>Chopped Brisket | $4.57 </h3>
              <p>Loaded with tender brisket, peppers and onions, two kinds of cheese, and topped off with jalapenos</p>
            </div> <br> <br>
            <div class="item-2">
              <h3>Peacamole Toast | $5.00 </h3>
              <p>A combination of well-seasoned chopped peas and eggs, topped on wheat flatbread</p>
            </div> <br> <br>
            <div class="item-3">
              <h3>Buddha Power Bowl | $6.90 </h3>
              <p>A satisfying mix of shredded carrots, corn, greens and protein to fuel your day </p>
            </div> <br> <br>
          </div>
        </div>

        <div class="menu-column" >
          <h2>Entrées</h2> <br>
          <div class="item-container">
            <div class="item-1">
              <h3>Short Rib Sliders | $4.57 </h3>
              <p>Tender beef short ribs cooked in a spicy-sweet peach and bourbon sauce and piled on a toasty slider bun</p>
            </div> <br> <br>
            <div class="item-2">
              <h3>Spicy Shrimp Tacos | $5.00 </h3>
              <p>Flame-roasted corn served with jalapeno bread</p>
            </div> <br> <br>
            <div class="item-3">
              <h3>Tailgater Collection | $6.90 </h3>
              <p>Pull together all the tasty fixins’ for a tailgate party spread to go</p>
            </div> <br> <br>
          </div>
        </div>

        <div class="menu-column" >
          <h2>Desserts</h2> <br>
          <div class="item-container">
            <div class="item-1">
              <h3>Sea Salt Caramel | $4.57 </h3>
              <p>Mouthwatering caramel with <br>
                a sprinkling of sea salt</p>
            </div> <br> <br>
            <div class="item-2">
              <h3>Wendell | $5.00 </h3>
              <p>A mix of smooth vanilla with the subtle 
                crunch of tasty cinnamon swirls</p>
            </div> <br> <br>
            <div class="item-3">
              <h3>Thai Tea | $6.90 </h3>
              <p>A satisfying blend of milky vanilla <br>
                goodness and Thai tea sweetness</p>
            </div> <br> <br>
          </div>
        </div>
      </diV>

      <a class="menu-order-btn" href="login.php">Order Now</a>

    </div>
  </div>


  
  <!-- FOOTER -->
  <footer class="footer">
    <div class="footer__addr">
      <h1 class="footer__logo">Brunch</h1>
          
      <h2>Contact</h2>
      
      <address>
        09 422 6555 (ext. 1)<br>
            
        <a class="footer__btn" href="@brunch.co.ph">Email Us</a>
      </address>
    </div>
    
    <ul class="footer__nav">
      <li class="nav__item">
        <h2 class="nav__title">Brunch</h2>
  
        <ul class="nav__ul">
          <li>
            <a href="menu.php">Menu</a>
          </li>
  
          <li>
            <a href="contact.php">Contact</a>
          </li>
              
          <li>
            <a href="about.php">About</a>
          </li>
        </ul>
      </li>
      
      <li class="nav__item nav__item--extra">
        <h2 class="nav__title">Social Media</h2>
        
        <ul class="nav__ul nav__ul--extra">
          <li>
            <a href="#">Facebook</a>
          </li>
          
          <li>
            <a href="#">Instagram</a>
          </li>
          
          <li>
            <a href="#">Twitter</a>
          </li>
    
    <div class="legal">
      <p>&copy; 2022 Brunch. All rights reserved.</p>
      <p>Serving you magnificence.</p>
      
    </div>
  </footer>
<!-- END OF FOOTER -->

</body>
</html>