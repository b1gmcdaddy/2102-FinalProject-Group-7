<?php

include '../Config/db_config.php';
session_start();

$conn = OpenCon();

		

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
     <link rel="stylesheet" href="../src/css/stylesheet.css">
<link rel="stylesheet" href="../src/css/order.css">
     <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">
</head>

<body>
   <body style="background-color: #EAEBE6;">

  <!-- HEADER -->
  <nav>
    <input type="checkbox" id="check">
    <label for="check" class="checkbtn">
      <i class="fas fa-bars"></i>
    </label>
    <div class="logo">
      <p>BRUNCH</p>
    </div>
    <ul>
      <li><a href="../public/index.php">HOME</a></li>
      <li><a href="../public/menu.php">MENU</a></li>
      <li><a href="../public/contact.php">CONTACT</a></li>
      <li><a href="../public/login.php">ACCOUNT</a></li>
      <li><a href="../public/about.php">ABOUT</a></li>
	<li><a href="../public/cart.php"><i class = "bi bi-cart2"></i></a>
	<?php
				
		$sql = "SELECT SUM(quantity) AS total FROM order_details WHERE orderID = 1 ";
		$result = $conn->query($sql);
		$temp = $result->fetch_assoc();
		if ($temp["total"] === NULL){
			echo 0;
		}else{
   			echo $temp['total'];
		}

			?>
	</li>
    </ul>
	
  </nav>

<div class = "footer">	
 <form action="invoice.php" method="post">
	<!-- Cart Section -->
          <?php
            $total = $_SESSION["totalPayment"];

            $result = mysqli_query($conn, $sql);

          $sql = "SELECT * 
                FROM order_details oi, customer_order od, food_menu p
                WHERE oi.orderID = od.orderID
                    AND oi.foodID = p.foodID
                    AND oi.orderID IN (
                        SELECT orderID
                        FROM customer_order
                        WHERE customerID = ".$_SESSION['userid']."
                    )
                GROUP BY oi.foodID;";

            $result = mysqli_query($conn, $sql);
              if (mysqli_num_rows($result) > 0) {
                  while ($row = mysqli_fetch_assoc($result)) {
                    $name = $row['food_name'];
                    $quantity = $row['quantity'];
                    $sql = "SELECT SUM(quantity) AS value_sum 
                            FROM order_details 
                            WHERE orderID IN (
                              SELECT orderID
                              FROM customer_order
                              WHERE customerID = 1
                            )";
                    $result = mysqli_query($conn, $sql); 
                    $row = mysqli_fetch_assoc($result); 
                    $sum = $row['value_sum'];	
            ?>
          <div class="col-md-4">
            <div class="card card-blue p-3 text-white mb-3">
              <span>
                You have to pay
              </span>
              <div class="d-flex flex-row align-items-end mb-3">
                <h1 class="mb-0 yellow">
                  ₱<?php echo $total ?>
                </h1>
              </div>
              <span>
                No. of Items:
                <b style="color: yellow; font-size:20px;">
                  <?php echo $sum ?> pcs.
                </b>
              </span>
              <!-- <span>Enjoy all the features and perk after you complete the payment</span>
              <a href="#" class="yellow decoration">Know all the features</a> -->
              <ul class="list-group mb-3">
              <?php
                $sql = "SELECT oi.quantity, p.food_name, p.food_price
                        FROM order_details oi 
                        INNER JOIN food_menu p 
                          ON oi.foodID = p.foodID
                        WHERE oi.orderID IN (
                          SELECT orderID 
                          FROM customer_order 
                          WHERE customerID = ".$_SESSION['userid']."
   
                        );";
                $result = mysqli_query($conn, $sql);
                  if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                      $name = $row['food_name'];
                      $quantity = $row['quantity'];
                      $product_price = $row['food_price'];
              ?>	
                      <li class="list-group-item d-flex justify-content-between lh-condensed">
                        <div>
                          <!-- <h6 class="my-0">Product name</h6> -->
                          <small class="text-muted">
                            <?php echo $quantity?>x <?php echo $name?>
                          </small>
                        </div>
                        <span class="text-muted">
                          ₱<?php echo $product_price*$quantity?>
                        </span>
                      </li>
	
              <?php
                    }
                  }
              ?> 
              </ul>
		<div class="row mt-3">
                <div class="col-md-6">
                  <div class="mt-1 mr-2">
                    <div class="custom-control custom-radio">
                      <input id="credit" name="payment-method" type="radio" class="custom-control-input"
                      checked required>
                      <label class="custom-control-label" for="credit">
                        Cash
                      </label>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="mt-1 mr-2">
                    <div class="custom-control custom-radio">
                      <input id="debit" name="payment-method" type="radio" class="custom-control-input"
                      required>
                      <label class="custom-control-label" for="debit">
                        Credit
                      </label>
                    </div>
                  </div>
                </div>
              </div>
		<a href="invoice.php">
   	 <button type="submit" name="submit" onClick="invoice.php" class="checkout">Pay now</button>
   	 </a>
              <?php

      }
	
    } else {
      echo "        <div class='item'>
      <div class='details'>
          <h1>0 Products</h1>
      </div>
	
  </div>";
    }
    mysqli_close($conn);
    ?>
</form>
</div>


 

 <div id="label" class="text-center"></div>


 <!-- FOOTER -->
  <footer class="footer">
    <div class="footer__addr">
      <h1 class="footer__logo">Brunch</h1>
          
      <h2>Contact</h2>
      
      <address>
        09 422 6555 (ext. 1)<br>
            
        <a class="footer__btn" href="@brunch.co.ph">Email Us</a>
      </address>
    </div>
    
    <ul class="footer__nav">
      <li class="nav__item">
        <h2 class="nav__title">Brunch</h2>
  
        <ul class="nav__ul">
          <li>
            <a href="menu.php">Menu</a>
          </li>
  
          <li>
            <a href="contact.php">Contact</a>
          </li>
              
          <li>
            <a href="about.php">About</a>
          </li>
        </ul>
      </li>
      
      <li class="nav__item nav__item--extra">
        <h2 class="nav__title">Social Media</h2>
        
        <ul class="nav__ul nav__ul--extra">
          <li>
            <a href="#">Facebook</a>
          </li>
          
          <li>
            <a href="#">Instagram</a>
          </li>
          
          <li>
            <a href="#">Twitter</a>
          </li>
    
    <div class="legal">
      <p>&copy; 2022 Brunch. All rights reserved.</p>
      <p>Serving you magnificence.</p>
      
    </div>
  </footer>
<!-- END OF FOOTER -->

