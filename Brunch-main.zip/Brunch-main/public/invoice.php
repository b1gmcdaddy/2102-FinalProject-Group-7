<?php
session_start();
include "../Config/db_config.php";

$conn = OpenCon();
    $method = $_POST["payment-method"];
    $get_order_id = "SELECT orderID FROM customer_order WHERE customerID = 1;";
	$temp = $conn->query($get_order_id);
	if($temp->num_rows > 0){ 
	$order_id = $temp->fetch_assoc();

   	$sql = "INSERT INTO payment(payment_date,payment_method,orderID) VALUES (" . date("Y-m-d") . "," . $method . "," . $order_id["orderID"] . ")";
		
}
else{
echo "<script>
                window.history.go(-1);
        </script>";
}



    ?>
