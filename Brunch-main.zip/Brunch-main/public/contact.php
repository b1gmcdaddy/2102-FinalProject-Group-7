<!DOCTYPE html>
<html>
    <head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
     <link rel="stylesheet" href="../src/css/stylesheet.css">
     <link rel="stylesheet" href="../src/css/contact.css">
     <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">
      <title>Contact Us</title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
<body style="background-color: #EAEBE6;">

  <nav>
    <input type="checkbox" id="check">
    <label for="check" class="checkbtn">
      <i class="fas fa-bars"></i>
    </label>
    <div class="logo">
      <p>BRUNCH</p>
    </div>
    <ul>
       <li><a href="../public/index.php">HOME</a></li>
      <li><a href="../public/menu.php">MENU</a></li>
      <li><a href="../public/contact.php">CONTACT</a></li>
      <li><a href="../public/login.php">ACCOUNT</a></li>
      <li><a href="../public/about.php">ABOUT</a></li>
	<li><a href="../public/cart.php"><i class = "bi bi-cart2"></i></a>
    </ul>
  </nav>
  <br><br>
  
  <div class="text-container">
  <h2>CONTACT US</h2>
    <p>Kindly feel free to send us a message.</p>
    <p>We look forward to hearing from you and will be back in touch as soon as possible.</p>
</div>

  <form action="/contact" method="post">
    <label for="name">Name:</label><br>
    <input type="text" id="name" name="name" required><br>
    <label for="name">Phone Number:</label><br>
    <input type="text" id="phone" name="phone" required><br>
    <label for="email">Email:</label><br>
    <input type="email" id="email" name="email" required><br>
    <label for="message">Message:</label><br>
    <textarea id="message" name="message" rows="5" required></textarea><br>
    <input type="submit" value="Submit">
  </form> 

  <!-- FOOTER -->
  <footer class="footer">
    <div class="footer__addr">
      <h1 class="footer__logo">Brunch</h1>
          
      <h2>Contact</h2>
      
      <address>
        09 422 6555 (ext. 1)<br>
            
        <a class="footer__btn" href="@brunch.co.ph">Email Us</a>
      </address>
    </div>
    
    <ul class="footer__nav">
      <li class="nav__item">
        <h2 class="nav__title">Brunch</h2>
  
        <ul class="nav__ul">
          <li>
            <a href="#">Menu</a>
          </li>
  
          <li>
            <a href="#">Contact</a>
          </li>
              
          <li>
            <a href="#">About</a>
          </li>
        </ul>
      </li>
      
      <li class="nav__item nav__item--extra">
        <h2 class="nav__title">Social Media</h2>
        
        <ul class="nav__ul nav__ul--extra">
          <li>
            <a href="#">Facebook</a>
          </li>
          
          <li>
            <a href="#">Instagram</a>
          </li>
          
          <li>
            <a href="#">Twitter</a>
          </li>
    
    <div class="legal">
      <p>&copy; 2022 Brunch. All rights reserved.</p>
      <p>Serving you magnificence.</p>
      
    </div>
  </footer>
<!-- END OF FOOTER -->

</body>
</html>