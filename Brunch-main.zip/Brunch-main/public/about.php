<!DOCTYPE html>
<html>
    <head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
     <link rel="stylesheet" href="../src/css/stylesheet.css">
     <link rel="stylesheet" href="../src/css/aboutus.css">
     <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">
      <title>About Us</title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
<body style="background-color: #EAEBE6;">

  <nav>
    <input type="checkbox" id="check">
    <label for="check" class="checkbtn">
      <i class="fas fa-bars"></i>
    </label>
    <div class="logo">
      <p>BRUNCH</p>
    </div>
    <ul>
       <li><a href="../public/index.php">HOME</a></li>
      <li><a href="../public/menu.php">MENU</a></li>
      <li><a href="../public/contact.php">CONTACT</a></li>
      <li><a href="../public/login.php">ACCOUNT</a></li>
      <li><a href="../public/about.php">ABOUT</a></li>
	<li><a href="../public/cart.php"><i class = "bi bi-cart2"></i></a>
    </ul>
  </nav>
  <br><br>
 
      <div class="img-container">
        <img src="../src/img/aboutimg.jpg">
        <div class="text">
          <h1>OUR RESTAURANT</h1><br><hr><br>
          Having moved from the original site in Leigh, Brunch has been turning out dishes from premises just out of Matakana since February 2016. The end of July 2016 we opened the doors to visitors and locals to experience the kind of hospitality Brunch is about - straight forward and generous.
          <br><br><br>
          <p class="subhead">Awarded Chefs</p>
          San Diego punches well above its weight when it comes to restaurants and chefs with heavy-hitting credentials. A Top Chef winner? Yep, we have one. Master French Chef? That, too. James Beard honors and nominations? Too many to count. Here are but a few of the proudest sons, daughters, and kitchens of San Diego.
            </div></div>

  <!-- FOOTER -->
  <footer class="footer">
    <div class="footer__addr">
      <h1 class="footer__logo">Brunch</h1>
          
      <h2>Contact</h2>
      
      <address>
        09 422 6555 (ext. 1)<br>
            
        <a class="footer__btn" href="@brunch.co.ph">Email Us</a>
      </address>
    </div>
    
    <ul class="footer__nav">
      <li class="nav__item">
        <h2 class="nav__title">Brunch</h2>
  
        <ul class="nav__ul">
          <li>
            <a href="#">Menu</a>
          </li>
  
          <li>
            <a href="#">Contact</a>
          </li>
              
          <li>
            <a href="#">About</a>
          </li>
        </ul>
      </li>
      
      <li class="nav__item nav__item--extra">
        <h2 class="nav__title">Social Media</h2>
        
        <ul class="nav__ul nav__ul--extra">
          <li>
            <a href="#">Facebook</a>
          </li>
          
          <li>
            <a href="#">Instagram</a>
          </li>
          
          <li>
            <a href="#">Twitter</a>
          </li>
    
    <div class="legal">
      <p>&copy; 2022 Brunch. All rights reserved.</p>
      <p>Serving you magnificence.</p>
      
    </div>
  </footer>
<!-- END OF FOOTER -->

</body>
</html>